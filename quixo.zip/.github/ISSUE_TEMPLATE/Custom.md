---
name: "\U0001F4AC Support Question"
about: If you have a "How to" question, please check out CONTRIBUTION.md!

---

We primarily use GitHub as an issue tracker; for usage and support questions, please use the correct way to do it as indicated in the contribution guide Thanks! 😁.
