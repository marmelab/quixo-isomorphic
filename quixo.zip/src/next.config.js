module.exports = {
    target: 'serverless',
    env: {
        API_HOST: 'localhost:3001',
    },
};
