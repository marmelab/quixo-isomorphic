export const CROSS_VALUE = 1;
export const CIRCLE_VALUE = -1;
export const NEUTRAL_VALUE = 0;
