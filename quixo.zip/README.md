# Quixo isomorphic - With React & Next.JS

## Installation

```bash
make install
```

## Start

```bash
make start
```

## Stop

```bach
make stop
```

## Test

```bash
make test
```

## License

Quixo-isomorphoc is licensed under the [MIT License](LICENSE), courtesy of [Marmelab](http://marmelab.com).
